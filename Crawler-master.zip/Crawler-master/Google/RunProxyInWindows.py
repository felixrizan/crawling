
from Google.Cloud import MySQL
import time

MySQL = MySQL(database_name="OmniCrawler")
while True:
    time.sleep(10)
