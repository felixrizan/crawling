USE Ecommerce;
SHOW TABLES;
SELECT * FROM Ecommerce_login;
SELECT * FROM Ecommerce_running_log;
SELECT * FROM Ecommerce_merchant;
SELECT * FROM Ecommerce_product;
SELECT * FROM Ecommerce_search;
DROP TABLE Ecommerce_search, Ecommerce_product, Ecommerce_merchant, Ecommerce_running_log, Ecommerce_login;